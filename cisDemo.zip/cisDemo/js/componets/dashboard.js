class Dashboard extends React.Component {
    render() {
        return (
            <div className="panel panel-default">
                <Menu />
                <TradeSelect />
                <TradeBody />
            </div>

        );
    }
}

ReactDOM.render(
    <Dashboard  />,
    document.getElementById('root')
);