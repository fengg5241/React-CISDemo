class TradeBody extends React.Component {
    render() {
        return (
            <div className="panel-body">
                <form>
                    <div className="form-group">
                        <label>Commodity:</label>
                        <select className="form-control">
                            <option>XU2</option>
                            <option>XU3</option>
                            <option>XU4</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Strategy:</label>
                        <input type="checkbox" className="form-check-input" id="strategyAllCheck" />
                        <label className="form-check-label" for="strategyAllCheck">All</label>

                        <select className="form-control">
                            <option>Strategy1</option>
                            <option>Strategy2</option>
                            <option>Strategy3</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Quantity(XU2):</label>
                        <input className=""/>
                        <select className="form-control">
                            <option>tOz</option>
                            <option>tOz2</option>
                            <option>tOz3</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Maturity Date(XU2 Leg):</label>
                        <input id="date" classname="form-control" type="date" />
                    </div>

                    <div className="form-group">
                        <label>Comment:</label>
                        <input id="comment" className="form-control"/>
                    </div>
                </form>
            </div>

        )
    }
}
