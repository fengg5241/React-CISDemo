class TradeSelect extends React.Component {
    render() {
        return (
        <div className="panel-body">
            <label>Category:</label>
            <select className="selectpicker">
                <option>Mustard</option>
                <option>Ketchup</option>
                <option>Relish</option>
            </select>
            <input type="button" value="Go" />
        </div>

        )
    }
}
