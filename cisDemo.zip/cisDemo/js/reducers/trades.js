import { GET_TRADE_CATEGROY, GET_TRADE_DETAIL, INSERT_TRADE} from '../constants/ActionTypes'

const initialState = [
  {
    categories: [{id:1,name:"INDIA_SPOT"}],
    selectedCategory: {id:1,name:"INDIA_SPOT"},
    detail: {}
  }
]

export default function trades(state=intialstate,action){
	switch(action.type){
		case:GET_TRADE_CATEGROY:
			return state;
		case:GET_TRADE_DETAIL:
			return state;
		case:INSERT_TRADE:
			return state;
		default:
			return state;
	}
}

