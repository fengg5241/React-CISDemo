import { combineReducers } from 'redux'
import trades from './trades'

const rootReducer = combineReducers({
  trades
})

export default rootReducer
