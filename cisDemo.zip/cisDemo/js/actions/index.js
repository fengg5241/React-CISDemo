import * as types from '../constants/ActionTypes'

export const getTrdeCategory = text => ({ type: types.GET_TRADE_CATEGROY })
export const getTrdeDetail = id => ({ type: types.GET_TRADE_DETAIL, id })
export const insertTrade = (id, trade) => ({ type: types.INSERT_TRADE, id, trade })




