import React from 'react'
import PropTypes from 'prop-types'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Menu from '../components/Header'
import TradeSelect from '../components/MainSection'
import TradeBody from '../components/MainSection'
import * as TradeActions from '../actions'

const App = ({todos, actions}) => (
	<div className="panel panel-default">
        <Menu />
        <TradeSelect selectChange={actions.getTrdeDetail}/>
        <TradeBody />
    </div>

  <div>
    <Header addTodo={actions.addTodo} />
    <MainSection todos={todos} actions={actions} />
  </div>
)

App.propTypes = {
  trades: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired
}

const mapStateToProps = state => ({
  trades: state.trades
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(TradeActions, dispatch)
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App)
